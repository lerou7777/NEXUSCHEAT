import { useState } from "react";

type PixResponse = {
  qrCodeBase64: string;
  copyPaste: string;
};

export function PaymentModal() {
  const [amount, setAmount] = useState(1000);
  const [pix, setPix] = useState<PixResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function gerarPix() {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch(
        "https://https://folly-backend-2.onrender.com/api/pix",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ amount }),
        }
      );

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error("Erro ao gerar PIX");
      }

      setPix({
        qrCodeBase64: data.qrCodeBase64,
        copyPaste: data.copyPaste,
      });
    } catch (err) {
      setError("Não foi possível gerar o PIX");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ padding: 24 }}>
      <h2>Adicionar saldo</h2>

      {!pix && (
        <>
          <select
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
          >
            <option value={1000}>R$ 10</option>
            <option value={2000}>R$ 20</option>
            <option value={5000}>R$ 50</option>
          </select>

          <br />

          <button onClick={gerarPix} disabled={loading}>
            {loading ? "Gerando PIX..." : "Gerar PIX"}
          </button>
        </>
      )}

      {error && <p style={{ color: "red" }}>{error}</p>}

      {pix && (
        <div style={{ marginTop: 24 }}>
          <img
            src={pix.qrCodeBase64}
            alt="QR Code PIX"
            style={{ width: 260 }}
          />

          <br />

          <button
            onClick={() => navigator.clipboard.writeText(pix.copyPaste)}
          >
            Copiar código PIX
          </button>
        </div>
      )}
    </div>
  );
}
